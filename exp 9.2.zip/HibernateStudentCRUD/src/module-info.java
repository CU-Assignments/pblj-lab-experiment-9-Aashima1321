/**
 * 
 */
/**
 * 
 */
module HibernateStudentCRUD {
}