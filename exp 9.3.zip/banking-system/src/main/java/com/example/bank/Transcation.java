ppackage com.example.bank.entity;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "transaction")
public class Transaction {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private int fromAccountId;
    private int toAccountId;
    private double amount;
    private LocalDateTime timestamp;

    public Transaction() {}
    public Transaction(int from, int to, double amount) {
        this.fromAccountId = from;
        this.toAccountId = to;
        this.amount = amount;
        this.timestamp = LocalDateTime.now();
    }

    // Getters & Setters
}

