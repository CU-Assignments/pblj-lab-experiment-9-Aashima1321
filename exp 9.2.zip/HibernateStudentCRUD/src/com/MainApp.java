package com;

public class MainApp {
    public static void main(String[] args) {
        StudentDAO dao = new StudentDAO();

        // Create
        Student s1 = new Student("Alice", 20);
        dao.addStudent(s1);
        System.out.println("Student Added: " + s1);

        // Read
        Student fetched = dao.getStudent(s1.getId());
        System.out.println("Fetched Student: " + fetched);

        // Update
        fetched.setAge(21);
        dao.updateStudent(fetched);
        System.out.println("Updated Student: " + dao.getStudent(fetched.getId()));

        // Delete
        dao.deleteStudent(fetched.getId());
        System.out.println("Deleted Student with ID: " + fetched.getId());
    }
}
