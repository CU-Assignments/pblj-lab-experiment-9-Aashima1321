package com.example.bank;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.example.bank.config.AppConfig;
import com.example.bank.entity.Account;
import com.example.bank.service.BankService;

import org.hibernate.SessionFactory;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class MainApp {
    public static void main(String[] args) {
        AnnotationConfigApplicationContext context = 
            new AnnotationConfigApplicationContext(AppConfig.class);

        BankService bankService = context.getBean(BankService.class);
        SessionFactory factory = context.getBean(SessionFactory.class);

        // Setup: Create sample accounts
        try (Session session = factory.openSession()) {
            Transaction tx = session.beginTransaction();
            session.save(new Account("Alice", 1000));
            session.save(new Account("Bob", 500));
            tx.commit();
        }

        // Test: Successful transfer
        try {
            bankService.transferMoney(1, 2, 200);
        } catch (Exception e) {
            System.out.println("Transfer failed: " + e.getMessage());
        }

        // Test: Failure transfer (Insufficient funds)
        try {
            bankService.transferMoney(1, 2, 10000);  // Should trigger rollback
        } catch (Exception e) {
            System.out.println("Transfer failed (as expected): " + e.getMessage());
        }

        context.close();
    }
}
